// useColorScheme.ts

export { useColorScheme } from 'react-native';
