import { View, Text } from 'tamagui'

export default function AIScreen() {
  return (
    <View flex={1} justifyContent="center" alignItems="center">
      <Text fontSize="$6" fontWeight="bold">AI Asistan</Text>
    </View>
  )
}
