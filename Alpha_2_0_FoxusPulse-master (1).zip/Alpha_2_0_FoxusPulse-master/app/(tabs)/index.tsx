import { View, Text } from 'tamagui'

export default function CalendarScreen() {
  return (
    <View flex={1} justifyContent="center" alignItems="center">
      <Text fontSize="$6" fontWeight="bold">Takvim</Text>
    </View>
  )
}
